// 項目配置
module.exports = {
  // 雲開發環境 ID（例如 'cloud1-xxxxxxx'）
  CLOUD_ENV: 'REPLACE_WITH_ENV_ID',
  // 訂閱消息模板 ID：「超时已退款」通知；在小程序後台「訂閱消息」申請後填入，留空則不請求授權
  TPL_TIMEOUT_REFUND: ''
}

