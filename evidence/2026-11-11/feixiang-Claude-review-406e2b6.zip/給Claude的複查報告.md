# feixiang-booking 複查報告（交給 Claude 修改）

審查日期：2026-11-11。審查版本：`406e2b6e7feb657d34972da7e28f0cc88ce33e2f`（main；結束前再次確認未變更）。

本次發現 **7 個已在本地隔離環境重現的問題：3 個 P1、4 個 P2**。最先處理 B1：失敗退款回退計數器，會重用另一筆退款的單號，造成少退款及帳目錯誤。B2、B3 會讓後面的退款一直等不到處理。建議先修 B1–B3，再驗收真實支付。

沒有修改業務程式，沒有部署雲函數，沒有操作真實付款或退款。下文的「微信」重現數字來自倉庫內的假支付服務，並非生產環境已發生的損失。

## 一、審查依據與過程

1. 透過 GitHub 連線讀取最新 main，固定上述完整提交編號，與上次版本 `7d7b5a2ace1ff064d5b349d33ba1388ab71c9028` 比較：新增 1 個提交、26 個檔案有修改。
2. 閱讀 `AGENTS.md`、立項書、需求規格書、技術方案書、澄清清單、任務清單、部署與測試說明；將文件與實作交叉比對。
3. 建立獨立程式快照，逐檔以 Git blob SHA 校驗，**196/196 個檔案與 GitHub 指定版本一致**。
4. 檢查客戶端訂場、切日期、購物車、立即購買、授權、付款、待支付、支付結果、訂單詳情和退款；追蹤 booking、admin、payNotify、timer 與共用訂單／支付邏輯。
5. 執行倉庫原有測試：`node tests/run.js`，**38/38 通過**。它包含偽造付款通知、取消後付款、退款重試、退款與核銷並發、庫存、價格、協議、資料清理等案例。
6. 另寫獨立重現程式 `audit-cases.cjs`，使用原有假雲開發環境；客戶端案例以 VM 執行實際頁面／工具程式。下列 **7/7 個問題均重現成功**，詳見 `audit-results.json`。
7. 整理原因、影響、建議與驗收條件。本次是原始碼與本地邏輯審查；未取得雲端日誌、控制台設定或真機執行證據。

優先級：P1＝應優先修復的款項／退款處理問題；P2＝影響正常操作或帳務日期，應在正式上線前修復。

## 二、問題總表

| 編號 | 優先級 | 問題 |
| --- | --- | --- |
| B1 | P1 | 退款失敗後回退次數，讓另一筆退款單號被重用，少退錢卻把券結案 |
| B2 | P1 | 前 20 筆長期結果不明的退款，擋住後面的退款補做 |
| B3 | P1 | 前 50 張失敗／處理中的過期券，擋住後面的自動退款 |
| B4 | P2 | 商品詳情頁改價後，重按「立即购买」仍一直提交舊價格 |
| B5 | P2 | 切日期尚未返回時的自動刷新，會撤掉客人剛選的日期 |
| B6 | P2 | 離開待支付頁後，舊輪詢仍可跳轉，打斷目前頁面 |
| B7 | P2 | 跨日補做成功的退款，報表記在申請日，導致每日實收錯誤 |

## 三、逐項重現與修改建議

### B1［P1］退款單號被重用，系統記帳與微信不一致

位置：[退款單號取自 refundCount](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/orders.js#L354)、[寫入退款記錄](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/orders.js#L386)、[失敗時將 refundCount 減一](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/orders.js#L473)。同份程式亦存在 booking/admin/timer/payNotify 的 lib。

**重現：**

1. 一張已付款訂單包含 P、Q、S 三種商品，各 ¥50。
2. 對 P 申請退款，取得 R01，讓微信回應暫時延遲。
3. 同時對 Q 退款，取得 R02，微信已受理並完成本地結算：已退 ¥50。
4. P 的舊請求此時才返回「餘額不足」，程式把 refundCount 從 2 減成 1。
5. 再對 S 退款，重新產生 R02，並以 set 覆蓋 Q 的退款記錄。
6. 模擬微信按照同一退款單號只退一次，對重複的 R02 返回成功；本地卻把它當成 S 的新退款結算。

**觀測結果：本地已退 ¥100，模擬微信只受理 ¥50；S 的券已記為退款失效。** Q 的退款記錄被改成 S，追帳亦受影響。這需要同一訂單不同卡片的退款交錯，客人、管理端與定時任務均共用此邏輯。

**原因：** 同一個可回退的數字，同時用來表示退款額度及產生唯一退款單號。失敗額度可以還回去，已發出的單號不能還回去。

**建議：**

- 分開「永不倒退的退款編號序列」與「已受理／仍預留的退款次數」；或使用永不重複的退款請求 ID。
- 新退款不得覆蓋既有記錄。同一請求重試沿用原單號，不同請求永不共用單號。
- 相容舊訂單時，從既有資料安全初始化序列，不能只照目前 refundCount 繼續編號。
- 保留失敗退款的歷史記錄；修共用程式後同步四個 lib。

**驗收：** 延遲失敗的 R01 不得影響 R02 的身份；第三筆取得全新單號。所有請求都明確完成後，訂單已退金額、退款記錄合計、支付服務受理金額一致；未真正退款的券不能被結案。

### B2［P1］退款補做隊列沒有輪轉，後面的退款可能永久排不到

位置：[timer.retryRefunds 查詢前 20 筆](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/timer/index.js#L52)、[未知結果只更新 lastTryAt，原 at 不變](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/orders.js#L480)。

**重現：** 建立 21 筆需要補做的退款；前 20 筆持續遇到無法確認的支付錯誤，第 21 筆服務已可正常受理。連跑 4 次每分鐘定時任務。

**觀測：** 第 21 筆申請次數仍為 0，狀態仍為 pending。每輪都按原始 at 取最老的 20 筆，重試後排序完全不變；只要舊 20 筆不結束，後面就沒有機會。

目前 G3 的修正只處理 confirmRefunds（已受理後查到帳），沒有處理此處 retryRefunds（未確認受理的補做）。

**建議：** 以 nextRetryAt／上次嘗試時間安排公平輪轉，在查詢中排除尚未到重試時間的記錄；必要時以游標分頁，確保時間預算內能處理後面的記錄。保留原退款單號與預留，不可為了讓隊列前進而任意宣告失敗。

**驗收：** 舊 20 筆一直失敗時，第 21 筆仍會在後續輪次被處理；同時驗證多次重試不重複退錢。

### B3［P1］過期券先取 50 張再略過，後面的券收不到自動退款

位置：[先 limit(50)，再略過退款中／冷卻中的記錄](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/timer/index.js#L99)。

**重現：** 建立 51 張不同卡片的過期券；前 50 張退款持續被微信明確拒絕，例如舊交易超過可退期限，最後一張可正常退款。跑 4 輪定時任務，輪次間隔 61 分鐘，跨過新設的一小時冷卻。

**觀測：** 最後一張一次都沒申請退款，仍為 codeActive=true、未記已過期。前 50 張失敗後仍符合最初查詢，下一輪又佔住名額；冷卻期間先取回它們再 continue，也沒有補取後面的資料。前 50 張若一直是 refunding，亦存在同類阻塞。

**建議：** 在資料庫查詢階段排除退款中與尚在冷卻中的記錄，或加入穩定排序與分頁，直到取得足夠的可處理項目或時間預算耗盡。不能只對已取回的固定 50 張做 continue。

**驗收：** 第 51 張在前 50 張仍失敗／退款中／冷卻中時，仍可退款並記為已過期；補做和掃描同時發生不重複退款。

### B4［P2］立即購買收到改價提示後，原頁無法重新購買

位置：[商品詳情 buyNow 沒處理 checkout.start 的結果](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/product/index.js#L51)、[PRICE_CHANGED 返回 invalid=true](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/utils/checkout.js#L75)。購物車頁有依 invalid 重新整理，商品詳情頁沒有。

**重現：** 客人打開 ¥50 商品詳情；管理端改成 ¥90；客人按立即購買，關閉「价格已变动」提示，再按一次。

**觀測：** 兩次都提交 expectTotal=5000，兩次均被 PRICE_CHANGED 拒絕。詳情頁仍保留 ¥50，沒有更新到 ¥90；不離開再進入就無法完成重新確認。

**建議：** 等待 checkout.start 的結果；若價格或商品失效，重新取得商品、刷新單價／庫存／數量及小計，讓客人看過新資訊後再點購買。不可直接忽略確認價格重送。

**驗收：** 第一次被擋下後原頁顯示 ¥90；客人再次確認可按新價格下單，不需返回列表。

### B5［P2］請求編號擋住舊回應，但仍可能把新選日期丟掉

位置：[load 的請求日期仍用 this.data.date](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/booking/index.js#L69)、[pickDate 等回應才更新日期](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/booking/index.js#L117)、[15 秒自動刷新](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/booking/index.js#L33)。

**重現：** 目前為 11/11；客人點 11/12，請求 A 尚未完成；此時 15 秒計時器發出請求 B。因畫面日期尚未更新，B 仍查 11/11，且取得較新的 seq。

**觀測：** A 的 11/12 回應被丟棄，B 的 11/11 被採用，最後仍顯示 11/11。原先「自動刷新在前、切日期在後」已修好，反過來的順序仍會錯。

**建議：** 分開保存「客人目前想看的日期」及「已渲染資料的日期」，自動刷新必須跟隨前者；或切換中暫停對舊日期輪詢。seq 仍可保留。

**驗收：** 兩種請求先後順序與任意回應順序，都以客人最後點的日期為準；格子、日期與加入購物車內容一致。

### B6［P2］待支付頁離開後，舊查單仍可跳轉

位置：[onHide/onUnload 只清 interval](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/order/pay/index.js#L18)、[check 的 setTimeout 未保存或清理](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/pages/order/pay/index.js#L67)。

**重現：** 待支付到期，查單暫時返回 pending，安排 3 秒後重試；客人離開該頁；執行舊重試，此時舊訂單返回 active。

**觀測：** 頁面已卸載後仍發出第二次請求，並執行跳轉至舊訂單的支付結果頁。真機上可能打斷客人目前正在看的頁面或新操作。原始碼中的失敗重試分支也沒有停止條件。

**建議：** 保存重試 timeout；onHide/onUnload 清理；加入頁面存活／顯示標記或請求代次，讓已在途請求的回應在離開後失效。再次 onShow 時只建立一條有效輪詢鏈。僅 clearTimeout 不足以處理已發出的請求。

**驗收：** 隱藏或卸載後，舊回應不 setData、不跳轉、不再安排重試；返回頁面時仍可正常恢復查單。

### B7［P2］跨日退款補做，報表把退款扣在錯誤日期

位置：[報表以 refunds.at 篩選](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/admin/index.js#L654)、[以 rf.at 分組](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/admin/index.js#L664)、[受理結算時另有 doneAt](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/orders.js#L451)。

規格與澄清 B7 定義退款按「退款日」，技術方案定義微信受理後記帳；at 實際是預留／申請時間。

**重現：** 北京時間 11/10 23:59 申請退 ¥50，網絡在發送至微信前中斷；11/11 00:02 定時補做，微信才首次受理並本地結算。

**觀測：** 11/10 報表列退款 ¥50；11/11 報表列退款 ¥0。款項總和未變，但每日實收錯日，舊日期報表還會在補做後突然改動。

**建議：** 明確區分申請時間、受理／記帳時間、最終到帳時間；按現有「受理即記帳」規則，以受理記帳時間（目前可用 doneAt，或新增 acceptedAt）篩選和分組。對舊資料制定一致回退規則，介面時間標籤亦應說清楚。

**驗收：** 上述案例退款列在 11/11，11/10 不扣這筆；日／月報和匯出一致。不要在未同步規格的情況下改成最終銀行到帳日。

## 四、文件與設定另外需要修正的地方

以下與上面 7 個重現問題分開記錄：

1. **模擬支付說明不完整，容易用錯模式。** [pay.js 第 10 行](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/_shared/pay.js#L10) 要同時滿足 PAY_MODE=mock 且 MCH_ID 為空才啟用模擬支付。因此四個雲函數若保留 MCH_ID，只增加 PAY_MODE=mock，仍會走真實支付。部署表格卻將 mock 說成測試、不扣真錢。請明確寫出優先順序及完整切換步驟，並加兩個設定同時存在的測試。是否改程式優先順序屬於設計選擇，不應自行悄悄更動。
2. **測試數字未同步。** [部署與測試](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/docs/部署與測試.md#L59) 仍寫 30 種，[任務清單](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/docs/05-任務清單.md#L159) 寫 32，實際為 38。
3. **保存年限的起算點不一致。** [隱私政策](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/miniprogram/utils/legal.js#L159) 寫自交易完成起至少 3 年，[timer](https://github.com/MERCURY2203/feixiang-booking/blob/406e2b6e7feb657d34972da7e28f0cc88ce33e2f/cloudfunctions/timer/index.js#L168) 卻按 createdAt 加 3 年。長期券很晚才用完時，兩者不同。先統一所承諾的規則，再依交易完成時間保存／匿名化；此為文案與程式一致性問題，本次未進行法律合規審查。
4. **正式資料仍待準備。** config.js 的 LEGAL 生效日、地址、聯繫方式等仍為空；訂閱模板 ID 亦為空，故目前客戶端不申請超時退款通知授權。這些是部署準備事項，不能由本地測試通過推定已配置完成。

## 五、已確認改善、預期設計及限制

- 原測試覆蓋的核心保護在本地均通過，包括付款主動查單、偽造通知無法直接改已付款、取消後付款走退款、同一場地並發只賣一份、退款沿用同一單號重試、退款與核銷互斥等。這不表示所有真實雲端情況已驗收。
- 上次確認後又改價的後端總價比對、微信沒有建單時逾時釋放、已受理退款的查詢排程、協議版本與伺服器成功後才放行，已有相應修正和測試。B4、B5 是目前尚未涵蓋的另一半流程。
- **協商只退部分金額並結束相應券，是店方已確認的預期設計，這次不當成 bug，也不要求補退差額。** 最新需求已解釋場地部分退款與券張數退款的差別，協議亦已補例外。
- 雲端環境、商戶號雖據店方表示已綁定，本次未驗證四個函數實際環境變量、退款授權、定時觸發器、超時設定、資料庫權限及真機完整支付鏈。
- 雲端驗收仍應包含小額真實付款、關閉付款窗、到期關單、取消後收到付款、全額／部分退款、退款查詢到帳及異常通知。應在上述修正後再進行驗收。

## 六、給 Claude 的執行要求

1. 先看本報告與最新 docs，修 B1、B2、B3，再修 B4–B7；若業務規則需調整，先更新文件。
2. 將這 7 個情境轉成正式回歸測試；不可只調整假支付服務讓錯誤看不出來。
3. 共用邏輯更新後執行 `node scripts/sync-shared.js`，確保四個 lib 一致。
4. 執行 `node tests/run.js`；也執行本報告附的重現程式，將「錯誤出現」的斷言改為「正確行為」的回歸斷言。
5. 回報每項修改位置、測試結果、需遷移的欄位及需重新部署的雲函數；保留已確認的協商部分退款設計。

## 七、附件使用方式

附件：`audit-cases.cjs`、`audit-results.json`、`source-manifest.json`。

在 Node.js 環境執行：

```text
node audit-cases.cjs "你的 feixiang-booking 專案根目錄"
```

也可把 `audit-cases.cjs` 放在專案根目錄後執行 `node audit-cases.cjs .`。不需要安裝支付依賴；程式沿用倉庫的 tests/fake-cloud.js，不連真實微信、不操作生產資料。測試使用虛構用戶／商品資料。

**注意：目前附件是「證明問題存在」的重現程式。** 執行成功、退出碼 0 表示 7 個錯誤情境全部被觀測到，不能當作程式已修好的證明。修正後應將對應斷言改成預期正確結果。測試會在附件所在目錄產生 audit-results.json。

